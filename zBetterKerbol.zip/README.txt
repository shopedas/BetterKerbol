Please delete ScatterAtmosphereCache* if your solar flare does not have any changes to it after mod installation.

This is my first ever mod. I made it out of pure rage as to how sun flares aren't really that realistic in other mods.
Please enjoy this mod, if there is any issues you may use the GitHub source code to make more advanced versions of this mod.

Im not planning on making any updates nor add whatever, I do not have any experience at all with coding. I read how other people had the same issue as me so I decided to make a public mod for it, I was afraid it would turn into a horrible mess and destroy my game but it works!

Dependant of Kopernicus and Scatterer.



[*ScatterAtmosphereCache saves solar flares and atmospheres to make loading times shorter, if I had coding experience I could make a code to auto clear it after installation
but as I have no experience you have to clear it yourself]